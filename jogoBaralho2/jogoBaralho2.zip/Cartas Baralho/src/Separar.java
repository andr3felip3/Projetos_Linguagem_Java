import java.*;


public class Separar {
	
}
