import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

public class Jogo extends JFrame {


	/**
	 * 
	 */
	private static final long serialVersionUID = -5492780116061103332L;

	List <Carta> morto = new ArrayList <Carta>();
	
	Baralho baralho;
	Carta c;
	JButton btFechado, btVazio, btAberto;
	JButton btCriaUm, btCriaQuatro, btEmbaralha, btExibe, btLimpa;
	Icon iconeFechado, iconeAberto, iconeVazio;
	
	public Jogo() {//construtor
		
		
		super ("Jogo de Cartas de Baralho.");
		setLayout(new BorderLayout());
		Icon iconeFechado = new ImageIcon(getClass().getResource("fechado.png"));
		Icon iconeVazio = new ImageIcon(getClass().getResource("vazio.png"));
		btFechado = new JButton (iconeVazio);
		btAberto = new JButton (iconeVazio);
		baralho = new Baralho();
		morto.clear();
		
		//adicionando bot�es no painel do centro
		JPanel painelcentro = new JPanel(new GridLayout(1,2,5,5));
		painelcentro.add(btFechado);
		painelcentro.add(btAberto);
		add(painelcentro, BorderLayout.CENTER);
		
		// adicionando bot�es no painel do sul/flow
		JPanel painelsul = new JPanel(new FlowLayout());
		btCriaUm = new JButton ("Criar um naipe");
		btCriaQuatro = new JButton ("Criar 4 naipes");
		btEmbaralha = new JButton("Embaralhar");
		btLimpa = new JButton("Limpar baralho");
		btExibe = new JButton("Exibe");
		painelsul.add(btCriaUm);
		painelsul.add(btCriaQuatro);
		painelsul.add(btEmbaralha);
		painelsul.add(btLimpa);
		painelsul.add(btExibe);
		add(painelsul, BorderLayout.SOUTH);
		
		//adicionando funcionalidade nos buttons
		//botao cria um
		btCriaUm.addActionListener(new ActionListener(){
			
			@Override
			public void actionPerformed(ActionEvent e) {
				
				baralho.zeraBaralho();
				baralho = new Baralho (1, 'c');
				btFechado.setIcon(iconeFechado);
				btAberto.setIcon(iconeVazio);
				
			}
		});
		
		//botao embaralha
		btEmbaralha.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				
				baralho.embaralha();
			
			}
		});
		
		//botao cria 4 naipes
		btCriaQuatro.addActionListener( new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				
				baralho.zeraBaralho();
				baralho = new Baralho(4,'c');
				btFechado.setIcon(iconeFechado);
				btAberto.setIcon(iconeVazio);
				
			}
		});
		
		//botao limpa baralho
		btLimpa.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				
				baralho.zeraBaralho();
				morto.clear();
				btFechado.setIcon(iconeVazio);
				btAberto.setIcon(iconeVazio);
				
			}
		});
		
		//botao para exibir
		btExibe.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				
				String saida = baralho.toString();
				JOptionPane.showMessageDialog(null, saida);
				
			}
		});
	
		//botao fechado
		btFechado.addActionListener( new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				
				if(baralho.quantidade() > 0) {
					
					c = baralho.getCarta(0);
					
					if(baralho.quantidade() == 0)
						btFechado.setIcon(iconeVazio);
					
					String figura = c.getImagem();
					iconeAberto = new ImageIcon(getClass().getResource(figura));
					btAberto.setIcon(iconeAberto);
					
				}
			}
		});
	}
	
	public static void main(String[] args) {
		
		Jogo j = new Jogo();
		
		j.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		j.setSize(670,300);
		j.setLocation(400,200);
		j.setVisible(true);

	}

}
